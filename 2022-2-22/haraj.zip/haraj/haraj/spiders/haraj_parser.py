import scrapy
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
import json

from haraj.items import *
from haraj.settings import *
# from sakneen.proxy import parse_proxy
from pymongo import MongoClient

headers = {
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "access-control-request-headers": "trackid",
    "access-control-request-method": "POST",
    "origin": "https://haraj.com.sa",
    "referer": "https://haraj.com.sa/",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.87 Safari/537.36"}


class HarajSpider(scrapy.Spider):
	# db = MongoClient('mongodb://localhost:27017')[dbname]
	name = 'haraj'
	allowed_domains = ['haraj.com.sa']

	def start_requests(self):
		with open('harajdata.json','r') as fp:
			data=fp.read()
		data=data.split("\n")
		meta={}
		for datas in data:
			datas=json.loads(datas)
			url=datas['url']
			meta['url']=url
			id=url.split('/')[-2]
			id=id[2:]
			meta['id']=id
			query={"query":"query postLikeInfo_postContact($id: Int!, $token: String,$postId: Int!) {\n\t\t\n\t\tpostLikeInfo(id: $id, token: $token)\n\t\t{ \n                    isLike\n                    total\n                    isFollowing\n                     }\n\t\n\r\n\t\tpostContact(postId: $postId)\n\t\t{ \n                    contactText\n                    contactMobile\n                     }\n\t\n\t}","variables":{"id":int(id),"token":"","postId":int(id)}}
			urls='https://graphql.haraj.com.sa/?queryName=postLikeInfo,postContact'
			yield Request(urls, callback=self.parse_data, method="POST",meta=meta, body=json.dumps(query),dont_filter=True,headers=headers)

	def parse_data(self,response):
		meta=response.meta
		# print(meta)
		v=json.loads(response.text)
		phone_no=v.get('data',{}).get('postContact',{}).get('contactMobile')
		meta['phone_no']=phone_no
		url='https://graphql.haraj.com.sa/?queryName=detailsPosts_singlePost'
		query={"query":"query($ids:[Int]) { posts( id:$ids) {\n\t\titems {\n\t\t\tid status authorUsername title city postDate updateDate hasImage thumbURL authorId bodyTEXT city tags imagesList commentStatus commentCount upRank downRank geoHash\n\t\t}\n\t\tpageInfo {\n\t\t\thasNextPage\n\t\t}\n\t\t} }","variables":{"ids":[int(meta['id'])]}}
		yield Request(url, callback=self.parse_search, method="POST",meta=meta, body=json.dumps(query),dont_filter=True,headers=headers)

	def parse_search(self,response):
		meta=response.meta
		option = json.loads(response.text)
		data=option['data']
		posts=data['posts']
		items=posts['items']
		nowdate = datetime.now().date()
		for item in items:
			broker_display_name =item['authorUsername']
			broker=broker_display_name.upper()
			category_url='tags/حراج%20العقار'
			title = item['title']
			description=item['bodyTEXT']
			if description:
				description = description.replace('\n', '').replace('\r', '').replace('\t', '').replace('\\', '')
			else:
				description = ''
			location=item['city']
			scraped_ts=nowdate.strftime("%Y_%m_%d")
			no_of_photos=len(item['imagesList'])
			date=nowdate.strftime("%Y_%m_%d")
			iteration_number=''
			user_id=item['id']
			published_at=item['updateDate']
			published_at=''

		item =  harajItem(id= '11'+str(meta['id']), 
			url = meta['url'],
			broker_display_name = broker_display_name,
			broker = broker,
			category_url = category_url,
			title = title,
			description = description,
			location = location,
			scraped_ts = scraped_ts,
			no_of_photos = no_of_photos,
			user_id = user_id,
			phone_number = meta['phone_no'],
			date = date,
			iteration_number = iteration_number,
			published_at = published_at,
			category='',
			property_type = '',
			depth =  '',
			sub_category_1 = '',
			sub_category_2 = '',
			price = '',
			currency = '',
			price_per = '',
			bedrooms = '',
			bathrooms = '',
			furnished = '',
			rera_permit_number ='',
			dtcm_licence = '',
			amenities = '',
			details = '',
			agent_name = '',
			reference_number = '',
			latitude ='',
			longitude = '',

			)
		yield item   



